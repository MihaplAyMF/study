
# Звіт по домашній роботі №8

В цій домашній роботі потрібно реалізувати 3 скрипти за допомогою bash

## 1. preview

Цей скрипт повинен приймати шлях до файлу і відповідно до типу файлу виводити необхідну інформацію.

```

```

## 2. Lsof

## 3. Crontab and logrotate

![image](https://github.com/MihaplAyMF/study/blob/main/BaseCamp/HomeWork7/Photo10.jpg)

